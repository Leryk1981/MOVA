# Changelog

## v0.1.0 — Перший стабільний реліз

- ✅ Додано CLI: `run`, `status`, `version`
- ✅ Додано MovaAPI з інтеграцією `engine`, `llm`, `validator`
- ✅ Приклад використання `quickstart.py`
- ✅ Покрито тести для CLI та API
- ✅ Підготовлено до CI/CD